<?php
require "connect.php";
$id=$_GET['Regno'];
$delete=mysqli_query($con,"DELETE FROM student WHERE Regno='$id'");
if($delete==1){
    header('Location:index2.php');
}else{
    echo"no data deleted";
}












?>