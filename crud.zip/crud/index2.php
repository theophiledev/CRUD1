<?php require 'connect.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Form</title>
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        .button-group {
            margin-top: 10px;
        }

        .button-group button {
            padding: 10px 20px;
            margin-right: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .button-group button.add {
            background-color: #4CAF50;
            color: white;
        }

        .button-group button.reset {
            background-color: #f44336;
            color: white;
        }
    </style>
</head>
<body>
<div class="container">
    <form method="POST" action="#">
        <table>
            <tr>
                <th>First Name</th>
                <td><input type="text" name="fname" placeholder="First Name..."></td>
            </tr>
            <tr>
                <th>Last Name</th>
                <td><input type="text" name="lname" placeholder="Last Name..."></td>
            </tr>
            <tr>
                <th>Location</th>
                <td><input type="text" name="location" placeholder="Location..."></td>
            </tr>
            <tr>
                <th>Age</th>
                <td><input type="number" name="age" placeholder="Age..."></td>
            </tr>
            <tr>
                <td></td>
                <td class="button-group">
                    <button type="submit" name="insert" class="add">Add</button>
                    <button type="reset" name="reset" class="reset">Reset</button>
                </td>
            </tr>
        </table>
    </form>

    <br><br>

    <table border="1">
        <thead>
        <tr>
            <th>Reg No</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Location</th>
            <th>Age</th>
            <th colspan="2">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php
		
		if (isset($_POST['insert'])) {
			$fname = $con->real_escape_string($_POST['fname']);
			$lname = $_POST['lname'];
			$location = $_POST['location'];
			$age = $_POST['age'];
			
			$insert = mysqli_query($con, "INSERT INTO student(FirstName, Lastname, Location, Age) VALUES ('$fname', '$lname', '$location', '$age')");
			
			if ($insert) {
				echo "New record inserted successfully.";
				header('Location: index2.php');
				exit; // Ensure script execution stops after redirection
			} else {
				echo "Error: " . mysqli_error($con);
			}
		}
		
        $select = mysqli_query($con, "SELECT * FROM student");
        if ($row = mysqli_num_rows($select) > 0) {
            while ($data = mysqli_fetch_array($select)) {
                ?>
                <tr>
                    <td><?php echo $data['Regno'] ?></td>
                    <td><?php echo $data['FirstName'] ?></td>
                    <td><?php echo $data['Lastname'] ?></td>
                    <td><?php echo $data['Location'] ?></td>
                    <td><?php echo $data['Age'] ?></td>
                    <td><a onclick="return confirm('Are you sure you want to delete')"
                           href="delete.php?Regno=<?php echo $data['Regno'] ?>">Delete</a></td>
                    <td><a onclick="return confirm('Are you sure you want to edit')"
                           href="update.php?Regno=<?php echo $data['Regno'] ?>">Edit</a></td>
                </tr>
                <?php
            }
        } else {
            echo "<tr><td colspan='6'>No record in table</td></tr>";
        }
        ?>
        </tbody>
    </table>
</div>
</body>
</html>
