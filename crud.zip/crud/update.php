<?php
require 'connect.php';

// Update Form
if (isset($_GET['Regno'])) {
    $regno = $_GET['Regno'];
    $select_query = "SELECT * FROM student WHERE Regno = '$regno'";
    $result = mysqli_query($con, $select_query);
    $row = mysqli_fetch_assoc($result);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Update Form</title>
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        table.form-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table.form-table th {
            text-align: left;
            padding: 8px;
        }

        table.form-table td {
            padding: 8px;
        }

        input[type="text"],
        input[type="number"],
        button[type="submit"] {
            padding: 10px;
            margin-bottom: 10px;
            width: calc(100% - 20px);
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
<div class="container">
    <form method="POST" action="#">
        <table class="form-table">
            <tr>
                <th>First Name</th>
                <td><input type="text" name="fname" value="<?php echo isset($row['FirstName']) ? $row['FirstName'] : ''; ?>"
                           placeholder="First Name..."></td>
            </tr>
            <tr>
                <th>Last Name</th>
                <td><input type="text" name="lname" value="<?php echo isset($row['Lastname']) ? $row['Lastname'] : ''; ?>"
                           placeholder="Last Name..."></td>
            </tr>
            <tr>
                <th>Location</th>
                <td><input type="text" name="location" value="<?php echo isset($row['Location']) ? $row['Location'] : ''; ?>"
                           placeholder="Location..."></td>
            </tr>
            <tr>
                <th>Age</th>
                <td><input type="number" name="age" value="<?php echo isset($row['Age']) ? $row['Age'] : ''; ?>"
                           placeholder="Age..."></td>
            </tr>
            <tr>
                <td></td>
                <td><button type="submit" name="update">Update</button></td>
            </tr>
        </table>
    </form>

    <?php
    if (isset($_POST['update'])) {
        $fname = $con->real_escape_string($_POST['fname']);
        $lname = $_POST['lname'];
        $location = $_POST['location'];
        $age = $_POST['age'];
        
        $update_query = "UPDATE student SET FirstName = '$fname', Lastname = '$lname', Location = '$location', Age = '$age' WHERE Regno = '$regno'";
        $update = mysqli_query($con, $update_query);
        
        if ($update) {
            echo "<p style='color: green;'>Record updated successfully.</p>";
            header('Location: index2.php'); // Redirect to the listing page after update
        } else {
            echo "<p style='color: red;'>Error updating record: " . mysqli_error($con) . "</p>";
        }
    }
    ?>
</div>
</body>
</html>
